package com.skyscanner;

import io.dropwizard.core.Configuration;

public class HoenScannerConfiguration extends Configuration {
    // No custom config values needed yet — add fields here (with @JsonProperty)
    // as the service grows, e.g. a "resultsDirectory" path or "defaultPageSize".
}
